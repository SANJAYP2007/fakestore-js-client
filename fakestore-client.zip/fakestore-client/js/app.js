// app.js – wires API, state and UI together.
import { getProducts, getCategories } from './api.js';
import { loadCart, saveCart, loadPrefs, savePrefs } from './state.js';
import * as ui from './ui.js';

const prefs = loadPrefs();
let cart = loadCart();
let products = [];
let categories = [];

const sorters = {
  default: () => 0,
  'price-asc': (a, b) => a.price - b.price,
  'price-desc': (a, b) => b.price - a.price,
  'rating-desc': (a, b) => b.rating.rate - a.rating.rate,
  'title-asc': (a, b) => a.title.localeCompare(b.title),
};

// Filter by category and search text, then sort. Pure function, easy to test.
function visibleProducts() {
  const q = prefs.query.trim().toLowerCase();
  return products
    .filter((p) => prefs.category === 'all' || p.category === prefs.category)
    .filter((p) => !q || p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q))
    .sort(sorters[prefs.sort] ?? sorters.default);
}

function refresh() {
  ui.renderTabs(categories, prefs.category, (c) => { prefs.category = c; savePrefs(prefs); refresh(); });
  ui.renderProducts(visibleProducts(), addToCart);
}

function renderCart() {
  ui.renderCart(cart, { onChange: changeQty, onClear: () => { cart = {}; persistCart(); } });
}

function persistCart() { saveCart(cart); renderCart(); }

function addToCart(product) { changeQty(product.id, 1, product); }

function changeQty(id, delta, product) {
  const line = cart[id] ?? (product && { product, qty: 0 });
  if (!line) return;
  line.qty += delta;
  if (line.qty <= 0) delete cart[id]; else cart[id] = line;
  persistCart();
}

async function load() {
  ui.hideError();
  ui.renderSkeletons();
  try {
    [products, categories] = await Promise.all([getProducts(), getCategories()]);
    refresh();
  } catch (err) {
    ui.renderProducts([], addToCart);
    ui.showError(err.message, load);
  }
}

function debounce(fn, ms = 200) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

function init() {
  const search = document.getElementById('search');
  const sort = document.getElementById('sort');
  search.value = prefs.query;
  sort.value = prefs.sort;

  search.addEventListener('input', debounce(() => { prefs.query = search.value; savePrefs(prefs); refresh(); }));
  sort.addEventListener('change', () => { prefs.sort = sort.value; savePrefs(prefs); refresh(); });
  document.getElementById('cart-toggle').addEventListener('click', ui.toggleCart);
  document.getElementById('error-close').addEventListener('click', ui.hideError);

  renderCart();
  load();
}

init();
