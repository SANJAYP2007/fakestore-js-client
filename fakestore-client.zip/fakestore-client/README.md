# Shelf – REST API Client

A vanilla ES6+ storefront that pulls live data from [FakeStoreAPI](https://fakestoreapi.com).

## Features
- `async/await` fetch with timeout (AbortController) and typed `ApiError`
- Live search (debounced), category tabs, and sorting with no page reloads
- Cart and filter preferences persisted in `localStorage`
- Loading skeletons and a dismissible error banner with a retry button

## Structure
| File | Responsibility |
|------|----------------|
| `js/api.js` | Network requests and error normalisation |
| `js/state.js` | `localStorage` read/write for cart and prefs |
| `js/ui.js` | DOM rendering helpers |
| `js/app.js` | Entry point: state, filtering pipeline, event wiring |

## Run locally
ES modules need a server (not `file://`):
```bash
npx serve .      # or: python3 -m http.server 8000
```

## Test the error state
Turn on offline mode in DevTools → Network, reload, and confirm the banner appears. Go back online and click **Try again**.
