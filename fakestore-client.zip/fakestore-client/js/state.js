// state.js – localStorage persistence for cart and user preferences.
const CART_KEY = 'shelf.cart.v1';
const PREFS_KEY = 'shelf.prefs.v1';

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback; // corrupted JSON or storage blocked
  }
}

function write(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage full or disabled: app keeps working in memory */
  }
}

export const loadCart = () => read(CART_KEY, {});          // { [productId]: { product, qty } }
export const saveCart = (cart) => write(CART_KEY, cart);
export const loadPrefs = () => read(PREFS_KEY, { category: 'all', sort: 'default', query: '' });
export const savePrefs = (prefs) => write(PREFS_KEY, prefs);
