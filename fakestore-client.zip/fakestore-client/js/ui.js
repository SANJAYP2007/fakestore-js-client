// ui.js – DOM rendering only; no fetching, no storage.
const $ = (id) => document.getElementById(id);
const money = (n) => `$${n.toFixed(2)}`;

function el(tag, props = {}, ...children) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

export function renderSkeletons(count = 8) {
  $('grid').replaceChildren(
    ...Array.from({ length: count }, () =>
      el('div', { className: 'card skeleton', ariaHidden: 'true' },
        el('div', { className: 'sk-img' }), el('div', { className: 'sk-line' }), el('div', { className: 'sk-line short' })))
  );
}

export function renderTabs(categories, active, onSelect) {
  const make = (value, label) => {
    const b = el('button', { className: `tab${value === active ? ' active' : ''}`, textContent: label });
    b.setAttribute('aria-pressed', String(value === active));
    b.addEventListener('click', () => onSelect(value));
    return b;
  };
  $('tabs').replaceChildren(make('all', 'All'), ...categories.map((c) => make(c, c)));
}

export function renderProducts(products, onAdd) {
  $('status').textContent = products.length ? `${products.length} product${products.length === 1 ? '' : 's'}` : '';
  if (!products.length) {
    $('grid').replaceChildren(el('p', { className: 'empty', textContent: 'No products match. Try a different search or category.' }));
    return;
  }
  $('grid').replaceChildren(...products.map((p) => {
    const img = el('img', { src: p.image, alt: p.title, loading: 'lazy' });
    const add = el('button', { textContent: 'Add to cart' });
    add.addEventListener('click', () => onAdd(p));
    return el('article', { className: 'card' },
      el('div', { className: 'img-wrap' }, img),
      el('h3', { textContent: p.title }),
      el('p', { className: 'meta', textContent: `${p.category} · ★ ${p.rating.rate} (${p.rating.count})` }),
      el('div', { className: 'row' }, el('strong', { textContent: money(p.price) }), add));
  }));
}

export function renderCart(cart, { onChange, onClear }) {
  const items = Object.values(cart);
  const count = items.reduce((n, i) => n + i.qty, 0);
  const total = items.reduce((n, i) => n + i.qty * i.product.price, 0);
  $('cart-count').textContent = count;
  $('cart-total').textContent = money(total);
  $('cart-items').replaceChildren(...(items.length ? items.map(({ product, qty }) => {
    const minus = el('button', { textContent: '−', ariaLabel: 'Remove one' });
    const plus = el('button', { textContent: '+', ariaLabel: 'Add one' });
    minus.addEventListener('click', () => onChange(product.id, -1));
    plus.addEventListener('click', () => onChange(product.id, 1));
    return el('li', {}, el('span', { textContent: product.title }), minus, el('span', { textContent: qty }), plus);
  }) : [el('li', { className: 'empty', textContent: 'Your cart is empty.' })]));
  $('cart-clear').onclick = onClear;
}

export function toggleCart() { $('cart').hidden = !$('cart').hidden; }

export function showError(message, onRetry) {
  $('error-text').textContent = message;
  $('error-banner').hidden = false;
  $('error-retry').onclick = () => { hideError(); onRetry?.(); };
  $('error-retry').hidden = !onRetry;
}
export function hideError() { $('error-banner').hidden = true; }
