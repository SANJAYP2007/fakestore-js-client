// api.js – all network access lives here.
const BASE_URL = 'https://fakestoreapi.com';

export class ApiError extends Error {
  constructor(message, status = null) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

async function request(path, { timeout = 8000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const res = await fetch(`${BASE_URL}${path}`, { signal: controller.signal });
    if (!res.ok) throw new ApiError(`The server responded with ${res.status}.`, res.status);
    return await res.json();
  } catch (err) {
    if (err instanceof ApiError) throw err;
    if (err.name === 'AbortError') throw new ApiError('The request took too long. Check your connection and try again.');
    throw new ApiError('Could not reach the store. Check your connection and try again.');
  } finally {
    clearTimeout(timer);
  }
}

export const getProducts = () => request('/products');
export const getCategories = () => request('/products/categories');
